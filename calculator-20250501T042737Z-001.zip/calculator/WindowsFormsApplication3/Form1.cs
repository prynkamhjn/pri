﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        double a=0, b=0, c=0;
        string s="0",e1;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            e1= Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            }       

            textBox1.Text += button1.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            }       
            textBox1.Text += button2.Text;

        }

        private void button3_Click(object sender, EventArgs e)
        {

            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } 
            textBox1.Text += button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (s!="0"||c!=0)
            {
                b = Convert.ToDouble(textBox1.Text);
                if (s == "+")
                    c = a + b;
                else if (s == "-")
                    c = a - b;
                else if (s == "*")
                    c = a * b;
                else if (s == "/")
                    c = a / b;
                else if (s == "%")
                    c = (a / b) * 100;
                textBox1.Text = Convert.ToString(c);
                a = c;
                s = button4.Text;
            }
            else
            {
                a = Convert.ToDouble(textBox1.Text);
                textBox1.Text = button4.Text;
                s = textBox1.Text;
                textBox1.Text = "";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            b = Convert.ToDouble(textBox1.Text);
            if (s == "+")
                c = a + b;
            else if (s == "-")
                c = a - b;
            else if (s == "*")
                c = a * b;
            else if (s == "/")
                c = a / b;
            else if (s == "%")
                c = (a / b)*100;
            textBox1.Text = Convert.ToString(c);
            c=0;
            s = "0";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button5.Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button6.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button8.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button13.Text;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button12.Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button11.Text;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            e1 = Convert.ToString(c);
            if (textBox1.Text == e1)
            {
                textBox1.Text = "";
            } textBox1.Text += button16.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (s != "0" || c != 0)
            {
               
                b = Convert.ToDouble(textBox1.Text);
                if (s == "+")
                    c = a + b;
                else if (s == "-")
                    c = a - b;
                else if (s == "*")
                    c = a * b;
                else if (s == "/")
                    c = a / b;
                else if (s == "%")
                    c = (a / b) * 100;
                textBox1.Text = Convert.ToString(c);
                a = c;
                s = button7.Text;
            }
            else
            {
                a = Convert.ToDouble(textBox1.Text);
                textBox1.Text = button7.Text;
                s = textBox1.Text;
                textBox1.Text = "";
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (s != "0" || c != 0)
            {
                b = Convert.ToDouble(textBox1.Text);
                if (s == "+")
                    c = a + b;
                else if (s == "-")
                    c = a - b;
                else if (s == "*")
                    c = a * b;
                else if (s == "/")
                    c = a / b;
                else if (s == "%")
                    c = (a / b) * 100;
                textBox1.Text = Convert.ToString(c);
                a = c;
                s = button10.Text;
            }
            else
            {
                a = Convert.ToDouble(textBox1.Text);
                textBox1.Text = button10.Text;
                s = textBox1.Text;
                textBox1.Text = "";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (s != "0" || c != 0)
            {
                b = Convert.ToDouble(textBox1.Text);
                if (s == "+")
                    c = a + b;
                else if (s == "-")
                    c = a - b;
                else if (s == "*")
                    c = a * b;
                else if (s == "/")
                    c = a / b;
                else if (s == "%")
                    c = (a / b) * 100;
                textBox1.Text = Convert.ToString(c);
                a = c;
                s = button14.Text;
            }
            else
            {
                a = Convert.ToDouble(textBox1.Text);
                textBox1.Text = button14.Text;
                s = textBox1.Text;
                textBox1.Text = "";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text ="0";

            textBox1.Text = "";
            s = "0";
            a = b = c = 0;
                 
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += button9.Text;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            b= Convert.ToDouble(textBox1.Text);
            textBox1.Text = button14.Text;
            s = textBox1.Text;
            textBox1.Text = "";
            c = (a / b)*100;
            textBox1.Text = Convert.ToString(c);
            
        }

    }
}
